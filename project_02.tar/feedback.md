# CPTR 142: Project #2
## Student: Hunter Kimes
## *Graded: March 1, 2022*
------
## Notes
* 

## Solution Checklist
* Program divided into functions which perform well-defined and logical sub-tasks for the problem: ✔
* Logical function groups in separate files: ✔
    * Separate the main program from supporting functions: ✔
* File that tests your supporting functions: ✔
* If using class, save each class in separate files: ✔
* Program contains at least three files: ✔
    * The main program: ✔
    * Supporting functions: ✔
    * Testing for the supporting functions: ✔
* Converted program: 

Answer these questions in the `REPORT.md` file.
* Describe original program: ✔
* What files are part of the original solutions: ✔
* What files are part of your converted solutions: ✔
* What challenges did you have converting your program: ✔
* What language was better suited for the task? Explain why: ✔
---
## TA GRADE: E