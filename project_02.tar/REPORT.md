# Project 2 Report

1. Describe original program.
The original program takes in a passage and gives it a reading difficulty rating.

2. What files are part of the original solutions?
The only file that it has is the main.

3. What files are part of your converted solutions?
The main, functions, and function test file.

4. What challenges did you have converting your program?
The main challenge I had was tring to find a way to iterate through a string like in C++.

5. What language was better suited for the task? Explain why?
They are both equaly suited in my opinion but I perfered python because it was less tedious.
